(() => {
  const progress = document.getElementById('scrollProgress');
  const menuToggle = document.getElementById('menuToggle');
  const nav = document.getElementById('mainNav');
  const toast = document.getElementById('toast');
  const savedCount = document.getElementById('savedCount');
  const lightbox = document.getElementById('lightbox');
  const lightboxImage = document.getElementById('lightboxImage');
  const lightboxClose = document.getElementById('lightboxClose');
  const savedDreams = new Set();
  let toastTimer;

  document.getElementById('year').textContent = new Date().getFullYear();

  const updateScroll = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const percent = max > 0 ? (window.scrollY / max) * 100 : 0;
    progress.style.width = `${Math.min(100, Math.max(0, percent))}%`;
  };
  window.addEventListener('scroll', updateScroll, { passive: true });
  updateScroll();

  menuToggle.addEventListener('click', () => {
    const open = menuToggle.getAttribute('aria-expanded') !== 'true';
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Tutup navigasi' : 'Buka navigasi');
    nav.classList.toggle('open', open);
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Buka navigasi');
  }));

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2300);
  }

  document.querySelectorAll('.dream-save').forEach(button => {
    button.addEventListener('click', () => {
      const card = button.closest('[data-dream]');
      const dream = card.dataset.dream;
      const pressed = button.getAttribute('aria-pressed') === 'true';
      if (pressed) {
        button.setAttribute('aria-pressed', 'false');
        button.querySelector('.save-icon').textContent = '＋';
        button.querySelector('.save-copy').textContent = 'Save to dream list';
        savedDreams.delete(dream);
        showToast(`${dream} dihapus dari dream list.`);
      } else {
        button.setAttribute('aria-pressed', 'true');
        button.querySelector('.save-icon').textContent = '✓';
        button.querySelector('.save-copy').textContent = 'Saved to dream list';
        savedDreams.add(dream);
        showToast(`${dream} masuk ke dream list!`);
      }
      savedCount.textContent = String(savedDreams.size).padStart(2, '0');
    });
  });

  function closeLightbox() {
    lightbox.classList.remove('open');
    lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    window.setTimeout(() => { lightboxImage.src = ''; }, 250);
  }
  document.querySelectorAll('.gallery-item').forEach(button => {
    button.addEventListener('click', () => {
      lightboxImage.src = button.dataset.full;
      lightbox.classList.add('open');
      lightbox.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    });
  });
  lightboxClose.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', event => { if (event.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeLightbox(); });
})();
