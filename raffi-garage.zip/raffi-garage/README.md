# RAFFI / GARAGE

Website profil personal untuk Raffi — car enthusiast, dengan wishlist BeamNG.drive, iQOO 15, dan PS5 Pro.

## Jalankan
- Buka `index.html` langsung di browser, atau
- Gunakan Live Server di VS Code untuk preview lokal.

## Struktur
- `index.html` — struktur halaman
- `style.css` — desain responsif, animasi, dan ilustrasi kendaraan CSS/SVG
- `script.js` — menu mobile, animasi reveal, scroll progress, dream list interaktif, dan photo lightbox
- `assets/` — foto yang diberikan untuk website

Website tidak membutuhkan framework atau build step. Font Google akan dimuat jika tersedia internet; font fallback tetap disediakan.
